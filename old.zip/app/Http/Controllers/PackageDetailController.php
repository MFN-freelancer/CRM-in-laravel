<?php

namespace App\Http\Controllers;

use App\PackageDetail;
use Illuminate\Http\Request;

class PackageDetailController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PackageDetail  $packageDetail
     * @return \Illuminate\Http\Response
     */
    public function show(PackageDetail $packageDetail)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PackageDetail  $packageDetail
     * @return \Illuminate\Http\Response
     */
    public function edit(PackageDetail $packageDetail)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PackageDetail  $packageDetail
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PackageDetail $packageDetail)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PackageDetail  $packageDetail
     * @return \Illuminate\Http\Response
     */
    public function destroy(PackageDetail $packageDetail)
    {
        //
    }
}
