<?php /* D:\SRILANK WORK\Laravel\crm(islael)\old\resources\views/user/order-detail.blade.php */ ?>
<?php $__env->startSection("content"); ?>

    <div class="content-body">
        <div class="container-fluid">
            <div class="row page-titles">
                <div class="col p-md-0">
                    <a href="javascript:void(0)" onclick="javascript: window.history.back();">
                        <h4><- Order Detail</h4>
                    </a>
                </div>
            </div>
            <div class="row">

                <div class="col-xl-12">
                    <div class="card forms-card">
                        <div class="card-body">
                            <div class="address">
                                <div><label><h3>CITY: <?php echo e($business[0]->city); ?></h3></label><h4></h4></div>
                                <div><label><h3>FLOOR: <?php echo e($business[0]->contact); ?></h3></label><h4></h4></div>
                            </div>
                            <div class="row package">
                                <?php for($i=0; $i<count($total_products);$i++): ?>

                                    <div class="col-lg-4">
                                        <div class="card">
                                            <div class="card-body">
                                                <h3 class="card-title"><?php echo e($total_products[$i][0]['name']); ?></h3>
                                                <div class="form-group row align-items-center">
                                                    <label class="col-sm-12 col-form-label text-label">
                                                        Quantity: <?php echo e($total_products[$i][0]['qty']); ?>

                                                    </label>
                                                </div>
                                                <div class="form-group row align-items-center">
                                                    <label class="col-sm-12 col-form-label text-label">
                                                      <?php echo e($total_products[$i][0]['desc']); ?>

                                                    </label>
                                                </div>

                                            </div>
                                        </div>
                                    </div>
                                <?php endfor; ?>
                            </div>

                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layouts.backend", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>