<?php /* D:\SRILANK WORK\Laravel\crm(islael)\old\resources\views/user/order-list.blade.php */ ?>
<?php $__env->startSection('content'); ?>
    <div class="content-body">
        <div class="container-fluid">
            <div class="row page-titles">
                <div class="col p-md-0">
                    <h4>Orders</h4>
                </div>
                <div class="col p-md-0">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item active">
                            <a href=""></a>
                        </li>
                    </ol>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table header-border" style="min-width: 500px;">
                                    <thead>
                                    <tr>
                                        <th>Time</th>
                                        <th>Customer</th>
                                        <th>Title</th>
                                        <th>Kind</th>
                                        <th>Floor</th>
                                        <th>Code</th>
                                        <th>Area</th>
                                        <th>Detail</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php ($no=0); ?>
                                    <?php for($i=0;$i<count($final_orders);$i++): ?>
                                    <tr>
                                        <td><?php echo e($final_orders[$i][0]['time']); ?></td>
                                        <td><?php echo e($final_orders[$i][0]['customer']); ?></td>
                                        <td><?php echo e($final_orders[$i][0]['address']); ?></td>
                                        <td><?php echo e($final_orders[$i][0]['kind']); ?></td>
                                        <td><?php echo e($final_orders[$i][0]['floor']); ?></td>
                                        <td> <?php echo e($final_orders[$i][0]['code']); ?></td>
                                        <td> <?php echo e($final_orders[$i][0]['area']); ?></td>
                                        <td><a href="<?php echo e(route('order-detail', $final_orders[$i][0]['order_id'])); ?>" class="btn
                                        btn-info
                                        btn-ft">View</a>
                                        </td>
                                    </tr>
                                    <?php endfor; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.backend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>