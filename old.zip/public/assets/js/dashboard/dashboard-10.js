
$(function () {
  "use strict";

  //write your JS code here...

});
